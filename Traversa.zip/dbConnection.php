<?php 
    $con = mysqli_connect('localhost','root','','WT');
    if (mysqli_connect_error()) {
        die("can not connect to databse right now");
    }
    else {
        
    }
?>